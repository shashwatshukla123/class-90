export const firebaseConfig = {
    apiKey: "AIzaSyCjGnMunet5Wyjh1kSdUw16V3Gs59QAOy4",
    authDomain: "the-learning-app-2990d.firebaseapp.com",
    databaseURL: "https://the-learning-app-2990d-default-rtdb.firebaseio.com",
    projectId: "the-learning-app-2990d",
    storageBucket: "the-learning-app-2990d.appspot.com",
    messagingSenderId: "679187602525",
    appId: "1:679187602525:web:df8370c2807f033dadc1b4"
  };
